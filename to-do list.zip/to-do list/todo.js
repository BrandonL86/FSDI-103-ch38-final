const todoList=["Take out the trash", "Pay the Bills", "Walk the Dog", "Fix the washing machine", "Take me Shopping", "Pick up the kids from School"];

let close = document.getElementsByClassName("close").innerHTML = todoList;
let span = document.createElement ("span");
span.className = "close";

function addTask() {
    const demandInput = document.getElementById("Demands");
    const demand = demandInput.value.trim();
    if (demand !== "") {
        todoList.push(demand);
        demandInput.value = "";
        displayTodoList();
    }
}
  
function removeTodoItem(li) {
    const index = todoList.indexOf(li);
    if (index > -1) {
        todoList.splice(index, 1);
        todoList.pop();
        document.getElementById(`Removed "${li}" from the to-do list.`).innerHTML = todoList;
    } else {
        document.write(`"${li}" is not found in the to-do list.`);
    }
}

  function displayTodoList() {
    const listContainer = document.getElementById("Listofdemands");
    let close = document.getElementsByClassName("close");
    span.className ="close";

    listContainer.innerHTML = "";
    for (let i = 0; i < todoList.length; i++) {
        const listItem = document.createElement("li");
        listItem.textContent = `${i + 1}. ${todoList[i]}`;
        listContainer.appendChild(listItem);
    }
}
